# Javascript-Course
## files for explanation in the youtube playlist https://www.youtube.com/playlist?list=PLYM2_EX_xVvWA3nMtsoLclwDtVS_rLk6O
