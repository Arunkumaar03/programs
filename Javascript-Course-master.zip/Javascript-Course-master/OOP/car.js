//ES6 - modules
export default class Car{
    drive(){
        console.log("Driving")
    }
}

export function fillGas(){
    console.log('Filling Gas')
}

export function repair(){
    console.log('Repairing')
}

// export default Car
// export {fillGas,repair}

