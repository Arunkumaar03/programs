//If else - conditional statement

let pwd_correct = false;

if (pwd_correct) {
  console.log("You are logged in");
} else {
  console.log("Incorrect password");
}

// Comparison Operators: ==  ===  !=  !==  >  <  >=  <=  ?: conditional/ternary
// Logical Operators: && || !

age = 65;
gender = "female";
if (age > 60 && gender === "female")
  console.log("You can avail special discount");

//max of two numbers
let a = 40, b = 30;
let max

if(a>b)
  max = a
else
  max = b

max = a>b?a:b


console.log(max)


console.log("Bye");
